package io.github.vivogameunlock;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.SystemClock;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

/** Provider and package-manager work happens only on a dedicated background thread. */
final class RuntimeState {
    private volatile Policy policy = closed();
    private volatile String packageList = "";
    private volatile boolean started;
    private Set<String> installed = Collections.emptySet();
    private long lastPackageScan;
    private boolean unavailableLogged;

    static Policy closed() {
        return new Policy(false, false, false, false, false, 120, "", "", Collections.emptySet());
    }
    Policy policy() { return policy; }
    String packages() { return packageList; }

    synchronized void start(Context context) {
        if (started || context == null) return;
        started = true;
        Context app = context.getApplicationContext();
        final Context ctx = app == null ? context : app;
        HandlerThread thread = new HandlerThread("VivoGameUnlockConfig");
        thread.start();
        Handler handler = new Handler(thread.getLooper());
        handler.post(new Runnable() {
            @Override public void run() {
                try {
                    Bundle b = ctx.getContentResolver().call(ConfigProvider.URI, "config", null, null);
                    if (b == null) throw new IllegalStateException("Empty module config");
                    if (lastPackageScan == 0 || SystemClock.elapsedRealtime() - lastPackageScan > 60000) {
                        Set<String> next = new HashSet<>();
                        for (ApplicationInfo ai : ctx.getPackageManager().getInstalledApplications(0)) {
                            if (ai.enabled && ai.uid % 100000 >= 10000
                                    && (ai.flags & ApplicationInfo.FLAG_SYSTEM) == 0)
                                next.add(ai.packageName);
                        }
                        installed = next;
                        lastPackageScan = SystemClock.elapsedRealtime();
                    }
                    Policy next = new Policy(b.getBoolean("enabled", true), b.getBoolean("all_apps", true),
                            b.getBoolean("memc", true), b.getBoolean("vsr", true), b.getBoolean("vaa", true),
                            b.getInt("target_fps", 120), b.getString("selected", ""), b.getString("excluded", ""), installed);
                    java.util.List<String> names = new java.util.ArrayList<>(next.packages());
                    Collections.sort(names);
                    packageList = android.text.TextUtils.join(";", names);
                    boolean first = !policy.enabled && next.enabled;
                    policy = next;
                    if (first) GameUnlock.log("CONFIG_READY candidates=" + names.size() + " target=" + next.targetFps);
                    unavailableLogged = false;
                } catch (Throwable t) {
                    // A missing/locked/uninstalled provider restores original behavior.
                    policy = closed(); packageList = "";
                    if (!unavailableLogged) {
                        GameUnlock.log("CONFIG_UNAVAILABLE: " + t.getClass().getSimpleName());
                        unavailableLogged = true;
                    }
                } finally { handler.postDelayed(this, 15000); }
            }
        });
    }
}
